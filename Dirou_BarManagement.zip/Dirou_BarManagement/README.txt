Les fichiers .java sont dans "src" et sont rangés selon l'arborescence du programme.


Pour démarer le programme : run le fichier "Lancher.java" dans lauchers